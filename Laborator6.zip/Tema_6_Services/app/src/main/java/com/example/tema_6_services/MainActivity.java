package com.example.tema_6_services;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    private EditText period;
    private EditText value;
    private EditText duration;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        period = findViewById(R.id.secondsInput);
        value = findViewById(R.id.valueInput);
        duration = findViewById(R.id.durationInput);
    }

    public void playSound(View view){
        int periodInt = Integer.parseInt(period.getText().toString());
        int valueInt = Integer.parseInt(value.getText().toString());
        int durationInt = Integer.parseInt(duration.getText().toString());

        Intent intent = new Intent(this,MyService.class);
        intent.putExtra("period",periodInt);
        intent.putExtra("value",valueInt);
        intent.putExtra("duration",durationInt);
        startService(intent);

    }
}