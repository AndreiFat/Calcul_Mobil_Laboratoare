package com.example.tema_6_services;

import android.app.Service;
import android.content.Intent;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.media.SoundPool;
import android.media.ToneGenerator;
import android.os.IBinder;

import java.io.ByteArrayOutputStream;


public class MyService extends Service {
    public MyService() {
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }

    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        int period = intent.getIntExtra("period",0)*1000;
        int value = intent.getIntExtra("value",0);
        int duration = intent.getIntExtra("duration",0);

        System.out.println(period);
        System.out.println(value);
        System.out.println(duration);

        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(period);
                    ToneGenerator toneGenerator = new ToneGenerator(AudioManager.STREAM_MUSIC,value);
                    toneGenerator.startTone(ToneGenerator.TONE_DTMF_5,duration);
                    System.out.println("PlaySound");
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

            }
        };
        Thread thread = new Thread(runnable);
        thread.start();
        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public void onDestroy() {
        System.out.println("Destroy!");
        super.onDestroy();
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        stopSelf();
        System.out.println("Removed!");
        super.onTaskRemoved(rootIntent);
    }
}