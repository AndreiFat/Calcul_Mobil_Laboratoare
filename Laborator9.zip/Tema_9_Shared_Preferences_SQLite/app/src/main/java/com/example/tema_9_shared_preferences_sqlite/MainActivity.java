package com.example.tema_9_shared_preferences_sqlite;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    ArrayAdapter arrayAdapter;
    DatabaseSupport databaseSupport;
    Student selectedStudent;
    private TextView textView;
    private EditText studentName, studentSurname, studentAge;
    private ListView listOfStudents;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = findViewById(R.id.textView);
        studentName = findViewById(R.id.studentName);
        studentSurname = findViewById(R.id.studentSurname);
        studentAge = findViewById(R.id.studentAge);
        listOfStudents = findViewById(R.id.listOfStudents);

        databaseSupport = new DatabaseSupport(MainActivity.this); //initializeaza baza de date
        arrayAdapter = new ArrayAdapter<Student>(MainActivity.this,
                android.R.layout.simple_list_item_1, databaseSupport.getAll());
        // adaptorul pentru baza de date care afiseaza toti utilizatorii

        listOfStudents.setAdapter(arrayAdapter); // initializez lista de studenti

        listOfStudents.setOnItemClickListener(new AdapterView.OnItemClickListener() { // din lista de studenti
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) { // cand apasat click pe un rand din lista
                selectedStudent = (Student) adapterView.getItemAtPosition(position); // preiau studentul de pe pozitia selectata
                studentName.setText(selectedStudent.getName()); // setez in input
                studentSurname.setText(selectedStudent.getSurname()); // setez in input
                studentAge.setText(String.valueOf(selectedStudent.getAge())); // setez in input
            }
        });
    }

    public void onCLickAdd(View view) {
        Student student = null;
        // preiau datele din input
        String name = studentName.getText().toString();
        String surname = studentSurname.getText().toString();
        int age = 0;
        // nu se poate face parasrea la INT daca input-ul este gol
        // asa ca am ales sa verific daca este diferit de ""
        if (!studentAge.getText().toString().equals("")) {
            age = Integer.parseInt(studentAge.getText().toString()); // si apoi sa se faca parsarea
        }
        try {
            // setez un nou student
            student = new Student(-1, name, surname, age);
        } catch (Exception e) {
            Toast.makeText(this, "Error while adding product", Toast.LENGTH_SHORT).show();
        }
        // adaug in baza de date
        boolean addedToDb = databaseSupport.addStudent(student);
        textView.setText("Student added to DB:" + addedToDb);

        // setez in lista item-ul nou
        arrayAdapter = new ArrayAdapter<Student>(MainActivity.this,
                android.R.layout.simple_list_item_1, databaseSupport.getAll());
        listOfStudents.setAdapter(arrayAdapter);
    }

    public void onClickDelete(View view) {
        databaseSupport = new DatabaseSupport(MainActivity.this);
        if (selectedStudent != null) { // daca exista student selectat il sterg la apasarea butonului
            databaseSupport.deleteStudent(selectedStudent);
            textView.setText("Student deleted from DB");
            arrayAdapter = new ArrayAdapter<Student>(MainActivity.this,
                    android.R.layout.simple_list_item_1, databaseSupport.getAll());
            listOfStudents.setAdapter(arrayAdapter); // setez lista
        } else {
            Toast.makeText(this, "Select a student first!", Toast.LENGTH_SHORT).show();
        }
    }

    public void onClickSearch(View view) {
        databaseSupport = new DatabaseSupport(MainActivity.this);
        String name = studentName.getText().toString();
        String surname = studentSurname.getText().toString();
        int age = 0;
        if (!studentAge.getText().toString().equals("")) {
            age = Integer.parseInt(studentAge.getText().toString());
        }
        String column;
        // verific in care input este introdus ceva..
        // daca este introdus in unul din input-uri atunci setez in care coloana din baza de date sa caute
        // iar apoi pe baza functiei getONE() setez lista cu utilizatorii gasiti
        if (!name.equals("")) {
            column = "STUDENT_NAME";
            databaseSupport.searchStudent(column, name);
            arrayAdapter = new ArrayAdapter<Student>(MainActivity.this,
                    android.R.layout.simple_list_item_1, databaseSupport.getOne(column, name));
            textView.setText("Student searched from name");
        } else if (!surname.equals("")) {
            column = "STUDENT_SURNAME";
            databaseSupport.searchStudent(column, surname);
            arrayAdapter = new ArrayAdapter<Student>(MainActivity.this,
                    android.R.layout.simple_list_item_1, databaseSupport.getOne(column, surname));
            textView.setText("Student searched from surname");
        } else if (!studentAge.getText().toString().equals("")) {
            column = "STUDENT_AGE";
            databaseSupport.searchStudent(column, studentAge.getText().toString());
            arrayAdapter = new ArrayAdapter<Student>(MainActivity.this,
                    android.R.layout.simple_list_item_1, databaseSupport.getOne(column, studentAge.getText().toString()));
            textView.setText("Student searched from age");
        } else {
            Toast.makeText(this, "No filter inserted!", Toast.LENGTH_SHORT).show();
            arrayAdapter = new ArrayAdapter<Student>(MainActivity.this,
                    android.R.layout.simple_list_item_1, databaseSupport.getAll());
        }
        listOfStudents.setAdapter(arrayAdapter);

    }

    // sterg datele din input-uri
    public void clearData(View view) {
        studentName.setText("");
        studentSurname.setText("");
        studentAge.setText("");
        arrayAdapter = new ArrayAdapter<Student>(MainActivity.this,
                android.R.layout.simple_list_item_1, databaseSupport.getAll());
        listOfStudents.setAdapter(arrayAdapter);
    }

// de la curs
    //    public void onCLickAdd(View view) {
//        Product product = null;
//        String name = productName.getText().toString();
//        int price = Integer.parseInt(productPrice.getText().toString());
//        boolean stock = isInStock.isChecked();
//
//        try {
//            product = new Product(-1, name, price, stock);
//        } catch (Exception e) {
//            Toast.makeText(this, "Error while adding product", Toast.LENGTH_SHORT).show();
//        }
//        boolean addedToDb = databaseSupport.addProduct(product);
//        textView.setText("Product added to DB:" + addedToDb);
//
//        arrayAdapter = new ArrayAdapter<Product>(MainActivity.this, android.R.layout.simple_list_item_1, databaseSupport.getAll());
//        listOfProducts.setAdapter(arrayAdapter);
//    }

//    public void onClickDelete(View view) {
//        databaseSupport = new DatabaseSupport(MainActivity.this);
//        databaseSupport.deleteProduct(selectedProduct);
//        textView.setText("Product deleted from DB");
//
//        arrayAdapter = new ArrayAdapter<Product>(MainActivity.this, android.R.layout.simple_list_item_1, databaseSupport.getAll());
//        listOfProducts.setAdapter(arrayAdapter);
//    }

}