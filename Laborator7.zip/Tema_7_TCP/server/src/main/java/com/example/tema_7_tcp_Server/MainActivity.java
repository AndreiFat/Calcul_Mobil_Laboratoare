package com.example.tema_7_tcp_Server;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class MainActivity extends AppCompatActivity {

    private TextView serverPort, serverIpAddress ,serverStatus , messageFromClientView, messageToSend;
    private String serverIp = "10.0.2.16";
    private int serverPortInt = 1234;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        serverPort = findViewById(R.id.serverPortView);
        serverIpAddress = findViewById(R.id.serverIpView);
        serverStatus = findViewById(R.id.serverStatus);
        messageFromClientView =findViewById(R.id.messageFromClient);
        messageToSend = findViewById(R.id.messageForClient);

        serverPort.setText(String.valueOf(serverPortInt));
        serverIpAddress.setText(serverIp);
    }

    private ServerThread serverThread;

    public void startServer(View view){
      serverThread = new ServerThread();
      serverThread.startServer();
    }
    public void stopServer(View view){
        serverThread.stopServer();
    }

    public void sendMessageToClient(View view){
        Socket socket = serverThread.returnSocket();
        String messageForClient = messageToSend.getText().toString();
        ManageMessages manageMessages = new ManageMessages(socket);
        manageMessages.send(messageForClient,socket);
    }

    class ServerThread extends Thread implements Runnable{

        private boolean serverRunning;
        private ServerSocket serverSocket;
        public Socket socket;

        public ServerThread(Socket socket) {
            this.socket = socket;
        }

        public ServerThread() {
        }

        public void startServer(){
            serverRunning= true;
            start();
        }

        public Socket returnSocket(){
            return socket;
        }

        @Override
        public void run() {
            try {
                serverSocket = new ServerSocket(serverPortInt);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        serverStatus.setText("Waiting for clients");
                    }
                });

                while (serverRunning){
                    socket =serverSocket.accept();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            serverStatus.setText("Connected to: "+ socket.getInetAddress()+ ":" + socket.getLocalPort());
//                            messageFromClientView.setText(messageFromServer);
                        }
                    });
                    ManageMessages manageMessages = new ManageMessages(socket,serverRunning);
                    String message = manageMessages.receive(socket);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            messageFromClientView.setText(message);
//                            messageFromClientView.setText(messageFromServer);
                        }
                    });
                    socket.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        public void stopServer(){
            serverRunning=false;
            new Thread(new Runnable() {
                @Override
                public void run() {
                    if(serverSocket!=null){
                        try {
                            serverSocket.close();
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    serverStatus.setText("Server Stop!");
                                }
                            });
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }).start();
        }
    }

    class ManageMessages extends Thread implements Runnable{
        private Socket socket;
        private boolean serverRunning;
        private String messageForClient;

        public ManageMessages(Socket socket, boolean serverRunning) {
            this.socket = socket;
            this.serverRunning = serverRunning;
        }

        public ManageMessages(Socket socket) {
            this.socket = socket;
        }

        public String receive(Socket socket){
            InputStreamReader inputStreamReader = null;
            String messageFromServer ="";
            try {
                inputStreamReader = new InputStreamReader(socket.getInputStream());
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                messageFromServer = bufferedReader.readLine();
            } catch (IOException e) {
                e.printStackTrace();
            }
           return messageFromServer;
        }

        public void send(String messageForClient, Socket socket){
            new Thread(new Runnable() {
                @Override
                public void run() {
                    PrintWriter output = null;
                    try {
                        output = new PrintWriter(socket.getOutputStream());
                        output.write("messageForClient 123");
                        output.flush();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }).start();

        }

    }

}