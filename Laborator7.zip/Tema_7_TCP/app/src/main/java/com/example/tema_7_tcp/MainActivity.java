package com.example.tema_7_tcp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class MainActivity extends AppCompatActivity {

    private EditText ipAddressInput, portInput;
    private EditText sendToServer;
    private TextView welcomeToServerView;
    private String serverName;
    private int serverPort;
    private Socket socket;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ipAddressInput = findViewById(R.id.ipAddressInput);
        portInput =findViewById(R.id.portInput);
        welcomeToServerView = findViewById(R.id.welcomeView);
        sendToServer = findViewById(R.id.sendToServer);
    }

    public void sendToServer(View view){
        String messageToServer = sendToServer.getText().toString();

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {

                    PrintWriter output = new PrintWriter(socket.getOutputStream());
                    output.write(messageToServer);
                    output.flush();
                    socket.close();

                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    public void onClickConnect (View view){
        serverName = ipAddressInput.getText().toString();
        serverPort = Integer.parseInt(portInput.getText().toString());

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    socket = new Socket(serverName,serverPort);

                    InputStreamReader inputStreamReader = new InputStreamReader(socket.getInputStream());
                    BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                    String messageFromServer = bufferedReader.readLine();

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            welcomeToServerView.setText(messageFromServer);
                        }
                    });
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }).start();

    }
}