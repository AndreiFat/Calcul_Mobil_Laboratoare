package com.example.tema_3_fragmente;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

public class MainActivity extends AppCompatActivity {

    int i = 0;
    int contor = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button leftButton = findViewById(R.id.leftButton);

        leftButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(i==0){
                    FragmentTwo imageFragment2 = new FragmentTwo();
                    replaceFragment(imageFragment2);
                    i++;
                    contor = 2;
                }
                else if(i==1){
                    FragmentThree imageFragment3 = new FragmentThree();
                    replaceFragment(imageFragment3);
                    i++;
                    contor = 3;
                }
                else if(i==2){
                    FragmentOne imageFragment1 = new FragmentOne();
                    replaceFragment(imageFragment1);
                    i = 0;
                    contor = 1;
                }
            }
        });

        Button rightButton = findViewById(R.id.rightButton);
        rightButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(i == 0){
                    FragmentThree imageFragment5 = new FragmentThree();
                    replaceFragment(imageFragment5);
                    i = 2;
                    contor = 3;
                }
                else if (i == 1){
                    FragmentOne imageFragment1 = new FragmentOne();
                    replaceFragment(imageFragment1);
                    i--;
                    contor = 1;
                }
                else if (i == 2){
                    FragmentTwo imageFragment2 = new FragmentTwo();
                    replaceFragment(imageFragment2);
                    i--;
                    contor = 2;
                }
            }
        });

        Button detailsButton = findViewById(R.id.detailsButton);
        detailsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                switch (contor)
                {
                    case 1:
                        DetailsOne detailsFragment1 = new DetailsOne();
                        replaceFragment(detailsFragment1);
                        break;
                    case 2:
                        DetailsTwo detailsFragment2 = new DetailsTwo();
                        replaceFragment(detailsFragment2);
                        break;
                    case 3:
                        DetailsThree detailsFragment3 = new DetailsThree();
                        replaceFragment(detailsFragment3);
                        break;
                    default:
                        Toast.makeText(MainActivity.this, "No more fragments", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public void replaceFragment(Fragment frParam){
        FragmentManager frManager = getSupportFragmentManager();
        FragmentTransaction frTransaction = frManager.beginTransaction();
        frTransaction.replace(R.id.fragmentContainerView, frParam, null);
        frTransaction.setReorderingAllowed(true);
        frTransaction.addToBackStack("name");
        frTransaction.commit();
    }
}