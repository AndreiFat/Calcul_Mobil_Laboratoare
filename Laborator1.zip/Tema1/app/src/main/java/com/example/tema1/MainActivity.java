package com.example.tema1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void onClicktoButtonSave(View view){
        EditText name = findViewById(R.id.name);
        EditText surname = findViewById(R.id.surname);
        EditText email = findViewById(R.id.email);

        TextView nameView = findViewById(R.id.nameView);
        TextView surnameView = findViewById(R.id.surnameView);
        TextView emailView = findViewById(R.id.emailView);

        nameView.setText("Name: "+name.getText().toString());
        surnameView.setText("Surname: "+surname.getText().toString());
        emailView.setText("Email: "+email.getText().toString());

        Toast.makeText(getApplicationContext(),"All data was saved!", Toast.LENGTH_LONG).show();
    }
    public void onClickShowToast(View view){
        Context context = getApplicationContext();
        CharSequence text = "This is a toast";
        int duration = Toast.LENGTH_SHORT;

        Toast toast = Toast.makeText(context,text,duration);
        toast.show();
    }
}