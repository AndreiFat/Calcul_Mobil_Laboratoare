package com.example.tema4_listview_recyclerview;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ListView listViewStudents;
    private EditText nameInput, surnameInput, ageInput;
    private ArrayList<Student> students = new ArrayList<>();
    private CustomAdapter customAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nameInput = findViewById(R.id.nameInput);
        surnameInput = findViewById(R.id.surnameInput);
        ageInput = findViewById(R.id.ageInput);

        customAdapter = new CustomAdapter(students, this);

        listViewStudents = findViewById(R.id.studentsList);
        listViewStudents.setAdapter(customAdapter);

    }
    public void addStudents(View view){
        String name = nameInput.getText().toString();
        String surname = surnameInput.getText().toString();
        int age=0;
        if(!ageInput.getText().toString().equals(""))
        {
            age = Integer.parseInt(ageInput.getText().toString());
        }
        students.add(new Student(name,surname,age));
        customAdapter.notifyDataSetChanged();
    }
}