package com.example.tema4_listview_recyclerview;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class CustomAdapter extends BaseAdapter implements ListAdapter {

    private TextView name,surname,age;
    private Button btnDelete;

    private ArrayList<Student> students;
    private Context context;

    public CustomAdapter(ArrayList<Student> students, Context context) {
        this.students = students;
        this.context = context;
    }

    @Override
    public int getCount(){
        return students.size();
    }

    @Override
    public Object getItem(int position) {
        return students.get(position);
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = convertView;
        // pregatesc Layout-ul
        if (view == null) {
            LayoutInflater inflater = (LayoutInflater)
                    context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(R.layout.custom_item, null);
        }
        //identific elementele
        name = view.findViewById(R.id.name);
        surname = view.findViewById(R.id.surname);
        age = view.findViewById(R.id.age);
        btnDelete = view.findViewById(R.id.deleteButton);

        name.setText(students.get(position).getName());
        surname.setText(students.get(position).getSurname());
        age.setText(String.valueOf(students.get(position).getAge()));


        btnDelete = view.findViewById(R.id.deleteButton);
        //ascult cand o sa fie apasat butonul
        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(context, "Item deleted: " + students.get(position).getName()
                        + " " + students.get(position).getSurname(), Toast.LENGTH_SHORT).show();
                students.remove(position); // sterg dupa pozitie
                notifyDataSetChanged();   // notific ca a fost schimbata o data
            }
        });

        return view;
    }
}
