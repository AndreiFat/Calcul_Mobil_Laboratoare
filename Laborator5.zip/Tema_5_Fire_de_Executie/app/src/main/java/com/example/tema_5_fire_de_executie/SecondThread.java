package com.example.tema_5_fire_de_executie;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class SecondThread implements Runnable {


    final Random random = new Random();
    private final Handler secondThreadHandler = new Handler();
    private int generatedNumber;
    private int minInterval;
    private int maxInterval;
    private TextView textView;
    private Context context;
    private Boolean run;
    private volatile boolean stopped;

    public SecondThread(int generatedNumber, int minInterval, int maxInterval, TextView textView, Context context, boolean stopped) {
        this.generatedNumber = generatedNumber;
        this.minInterval = minInterval;
        this.maxInterval = maxInterval;
        this.textView = textView;
        this.context = context;
        this.stopped = stopped;
    }

    @Override
    public void run() {
        run = true;
        final Runnable runnable = new Runnable() {
            @Override
            public void run() {
                if (!stopped) {
                    int randomNumber = random.nextInt((maxInterval - minInterval) + 1) + minInterval;
                    secondThreadHandler.postDelayed(this, 2000);
                    String showToUI = "Thread-ul a ales: " + randomNumber;
                    textView.setText(showToUI);
                    if (randomNumber == generatedNumber) {
                        run = false;
                        stopped = true;
                        Toast.makeText(context, "Thread-ul a castigat jocul!", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        };
        secondThreadHandler.post(runnable);
    }

}
