package com.example.tema_5_fire_de_executie;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    final Context context = this;
    //    private Button verifyNumber;
//    private Button newGame;
    public TextView showSecondThread;
    private TextView showUserNumber;
    private EditText minInterval;
    private EditText maxInterval;
    private EditText userNumber;
    private int randomNumber;
    private volatile boolean stopped = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        showSecondThread = findViewById(R.id.secondThreadShow);
//        showUserNumber = findViewById(R.id.userNumber);
        minInterval = findViewById(R.id.minInterval);
        maxInterval = findViewById(R.id.maxInterval);
        userNumber = findViewById(R.id.insertedUserNumber);
    }

    public void verifyNumber(View view) {
        String userNumberText = userNumber.getText().toString();
        int convertedUserNumber;
        try {
            convertedUserNumber = Integer.parseInt(userNumberText);
            if (convertedUserNumber == randomNumber) {
//                showUserNumber.setText("Felicitari ai castigat jocul!");
                Toast.makeText(getApplicationContext(), "Felicitari ai castigat jocul!", Toast.LENGTH_SHORT).show();
                stopThread();
            } else
                Toast.makeText(getApplicationContext(), "Mai incearca", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            System.out.println("Error");
        }

    }

    public void stopThread() {
        stopped = true;
    }

    public void newGame(View view) {
        Random random = new Random();
        String maxText = maxInterval.getText().toString();
        String minText = minInterval.getText().toString();
        int min = 0, max = 0;
        try {
            min = Integer.parseInt(minText);
            max = Integer.parseInt(maxText);
        } catch (NumberFormatException e) {
            System.out.println("number can not be converted.");
        }
        randomNumber = random.nextInt((max - min) + 1) + min;

        SecondThread secondThread = new SecondThread(randomNumber, min, max, showSecondThread, context, stopped);
        new Thread(secondThread).start();
    }
}
