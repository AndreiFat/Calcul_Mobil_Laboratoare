package com.example.tema_8_okhttp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private TextView showJson;
    private TextView jsonTrim;
    private String jsonURL = "http://www.floatrates.com/daily/ron.json"; // nu functioneaza acest json :)
    private String url = "https://api.freecurrencyapi.com/v1/latest?apikey=COH46J6gDuOSZFh6Dz8aFURzHiuaQ4193UPEVkI6&currencies=EUR%2CUSD%2CCAD%2CGBP%2CHUF&base_currency=RON";
    private RadioGroup radioGroup;
    private RadioButton eurCheckBox, usdCheckBox, cadCheckBox, gbpCheckBox, hufCheckBox;
    private EditText ronInserted;

    private float eur, usd, cad, gbp, huf;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        showJson = findViewById(R.id.showJson);
        jsonTrim = findViewById(R.id.jsonTrim);

        eurCheckBox = (RadioButton) findViewById(R.id.eurCB);
        usdCheckBox = (RadioButton) findViewById(R.id.usdCB);
        cadCheckBox = (RadioButton) findViewById(R.id.cadCB);
        gbpCheckBox = (RadioButton) findViewById(R.id.gbpCB);
        hufCheckBox = (RadioButton) findViewById(R.id.hufCB);
        radioGroup = (RadioGroup) findViewById(R.id.radioGroup);
        ronInserted = findViewById(R.id.ronInserted);

        // OkHttpClient pentru aducerea JSON-ului de pe API
        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder().url(url).build();
        Call call = client.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(MainActivity.this, "Something went wrong!", Toast.LENGTH_SHORT).show();
                    }
                });
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws
                    IOException {
                String receivedData = response.body().string();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        showJson.setText(receivedData);
                    }
                });

            }
        });
    }

    public void getData(View view) {
        // verificarea JSON-ului si prelucrarea lui pentru a putea fi utilizat
        if (showJson.getText() != null) {
            String jsonData = showJson.getText().toString();
            try {
                JSONObject jsonObject = new JSONObject(jsonData);
                String jsonTrimed = "EUR: " + jsonObject.getJSONObject("data").getString("EUR") + "\n" +
                        "CAD: " + jsonObject.getJSONObject("data").getString("CAD") + "\n" +
                        "GBP: " + jsonObject.getJSONObject("data").getString("GBP") + "\n" +
                        "USD: " + jsonObject.getJSONObject("data").getString("USD") + "\n" +
                        "HUF: " + jsonObject.getJSONObject("data").getString("HUF") + "\n";
                jsonTrim.setText(jsonTrimed);
                eur = Float.parseFloat(jsonObject.getJSONObject("data").getString("EUR"));
                cad = Float.parseFloat(jsonObject.getJSONObject("data").getString("CAD"));
                gbp = Float.parseFloat(jsonObject.getJSONObject("data").getString("GBP"));
                usd = Float.parseFloat(jsonObject.getJSONObject("data").getString("USD"));
                huf = Float.parseFloat(jsonObject.getJSONObject("data").getString("HUF"));
                Log.i(TAG, "getData: " + " " + eur + " " + cad + " " + gbp + " " + usd + " " + huf + " ");
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    public void convertToCurrency(View view) {
        // preiau si verific JSON-ul si il prelucrez
        if (showJson.getText() != null) {
            String jsonData = showJson.getText().toString();
            try {
                JSONObject jsonObject = new JSONObject(jsonData);
                eur = Float.parseFloat(jsonObject.getJSONObject("data").getString("EUR"));
                cad = Float.parseFloat(jsonObject.getJSONObject("data").getString("CAD"));
                gbp = Float.parseFloat(jsonObject.getJSONObject("data").getString("GBP"));
                usd = Float.parseFloat(jsonObject.getJSONObject("data").getString("USD"));
                huf = Float.parseFloat(jsonObject.getJSONObject("data").getString("HUF"));
                Log.i(TAG, "getData: " + " " + eur + " " + cad + " " + gbp + " " + usd + " " + huf + " ");
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        String input = ronInserted.getText().toString(); // preiau valoarea din input
        if (!input.equals("")) { // daca input-ul nu este gol pot sa fac prelucrarile
            Float numberInserted = Float.parseFloat(input);
            Float result;
            int checkedRadioButtonId = radioGroup.getCheckedRadioButtonId(); //preiau id-ul elementrului selectat din grup
            // verific daca id-ul elementului este egal cu id-ul radioButton-ului
            switch (checkedRadioButtonId) {
                case R.id.eurCB:
                    result = numberInserted * eur;
                    break;
                case R.id.usdCB:
                    result = numberInserted * usd;
                    break;
                case R.id.gbpCB:
                    result = numberInserted * gbp;
                    break;
                case R.id.hufCB:
                    result = numberInserted * huf;
                    break;
                case R.id.cadCB:
                    result = numberInserted * cad;
                    break;
                default:
                    result = 0.0f;
                    break;
            }
            jsonTrim.setText(String.valueOf(result)); // setez TextView-ul cu rezultatul obtinut
        } else { // daca este gol afisez Toast de avertizare
            Toast.makeText(this, "Insert a number first!", Toast.LENGTH_SHORT).show();
        }
    }
}