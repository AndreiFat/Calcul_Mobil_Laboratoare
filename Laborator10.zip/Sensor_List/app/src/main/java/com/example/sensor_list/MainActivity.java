package com.example.sensor_list;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.BatteryManager;
import android.os.Bundle;
import android.provider.Settings;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    private TextView textView, textView2;
    private SensorManager sensorManager;
    private List<Sensor> deviceSensorList;
    Context context =this;
    Sensor mySensor;
private BroadcastReceiver broadcastReceiver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = findViewById(R.id.textView);
        textView2 = findViewById(R.id.textView2);
        textView.setMovementMethod(new ScrollingMovementMethod());

        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        mySensor = sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT);

        if(mySensor == null){
            Toast.makeText(this, "No light sensor found", Toast.LENGTH_LONG).show();
            finish();
        }else{
            sensorManager.registerListener(this, mySensor, SensorManager.SENSOR_DELAY_NORMAL);
        }

        //        Settings.System.putInt(context.getContentResolver(),
//                Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL);
//        Settings.System.putInt(context.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS,
//                initialBrightness);

//        deviceSensorList = sensorManager.getSensorList(Sensor.TYPE_ALL);
//
//        textView.setText(deviceSensorList.toString());
//
//        for (Sensor sensor : deviceSensorList) {
//            textView.setText(textView.getText()+"\n"+ sensor.getName());
//
//        }

//        if (sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT)==null){
//            textView.setText("Your device does not have an ambient light sensor :(");
//        }
//        else {
//            textView.setText("Your device has an ambient light sensor");
//        }
    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        if (sensorEvent.sensor.getType() == Sensor.TYPE_LIGHT){
            textView.setText("Light intensity \n "+ sensorEvent.values[0]);
        }

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }

    @Override
    public void onStop(){
        super.onStop();
        sensorManager.unregisterListener(this);
    }

    public void viewBrightness(View view){
        // In the Activity
            new Thread(new Runnable() {
                @Override
                public void run() {
                    int initialBrightness = Settings.System.getInt(context.getContentResolver(),
                            Settings.System.SCREEN_BRIGHTNESS, 0);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            textView2.setText(String.valueOf("Level of phone brightness "+initialBrightness));
                        }
                    });
                }
            }).start();
    }

    public void startChecking(){
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction( Settings.System.SCREEN_BRIGHTNESS);
        int initialBrightness = Settings.System.getInt(context.getContentResolver(),
                Settings.System.SCREEN_BRIGHTNESS, 0);

        broadcastReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                textView2.setText(String.valueOf(initialBrightness));
            }
        };
        registerReceiver(broadcastReceiver,intentFilter);
    }

    @Override
    protected void onResume() {
        super.onResume();
        startChecking();
    }

    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(broadcastReceiver);
    }
}